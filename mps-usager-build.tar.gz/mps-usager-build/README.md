# MonParcoursSocial

## Use cozy-doctype in local
In order to be able to use our own cozy-doctype, especialy remote doctype here, we need to use them in local.

1/ clone cozy-doctype repository into your system.
Then, push it into your root project.

2/ After that, add your own remote doctype into cozy-doctype folder:
  - create a new folder ex: org.mps.share
  - push into this folder request file: request

You must declare this doctype into your manifest.webapp file like that :
    "share": {
          "description": "Required for searching on back-endTS",
          "type": "org.mps.share",
          "verbs": ["GET", "POST"]
        },


3/ In cozy-app-dev-with-app.sh, you need to add another option when you serve the cozy-stack:
  - cozy-stack serve --allow-root (...) --doctypes /path/to/the/doctype

=> in this project :
  -  cozy-stack serve (...) --doctypes /data/cozy-doctypes

!! Warning !! : You need to build and push the newlest image on the forge registry when the step 3 is done
!! Warning !! : You must have all files, into your docker folder, in LF mode of  "End of Line Sequence" !
For this project:
  - cd docker
  - docker build .
  - docker tag <image_ID_created> registry.forge.grandlyon.com/solidarite/monparcourssocial/mps-usager/cozy-env-doctypes
  - docker push registry.forge.grandlyon.com/solidarite/monparcourssocial/mps-usager/cozy-env-doctypes:latest

4/ The path "/data/cozy-doctypes" is link to the volume of the cozy-app-dev image.
  - in order to mount this volume, you need to add it when you run the 'docker run' command :
     -v $PWD/cozy-doctypes:/data/cozy-doctypes

    => for this project :
    docker run --rm -it -p 8080:8080 -p 5984:5984 -p 8025:8025 -v $PWD/build:/data/cozy-app/mps -v $PWD/data:/usr/local/couchdb/data -v $PWD/docker/disableCSP.yaml:/etc/cozy/cozy.yaml -v $PWD/cozy-doctypes:/data/cozy-doctypes registry.forge.grandlyon.com/solidarite/monparcourssocial/mps-usager/cozy-env-doctypes


# How to test your remote doctype ?
## GET
1/ In the request file created. Specify the methode and the route to your target URL :
    GET http://pilote-agent-dev.grandlyon.com/api/cozy

  or with value in query :

    GET http://pilote-agent-dev.grandlyon.com/api/auth/token/check?token={{token}}


2/ Then, you can test it by :
  - await client.getStackClient().fetchJSON('GET','/remote/org.mps.share')

  or with value in query :

  -  await client.getStackClient().fetchJSON('GET','/remote/org.mps.share?token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImNvenlBcGlDaGVjayIsInVzZXJJZCI6IjEiLCJpYXQiOjE2MDU2OTI0NjYsImV4cCI6MTYwNTY5MjUyNn0.HbQh5H-TcVIASUpbjZAD0MY9slRAJOVw-VMKSBu_sQ0' )

## POST
1/ In the request file created. Specify the methode and the route to your target URL :
    POST http://pilote-agent-dev.grandlyon.com/api/auth/token/check
    Content-Type: application/json

    {{data}}


2/ Then, you can test it by :
  const parameters = {
      data: JSON.stringify({
        token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VybmFtZSI6ImNvenlBcGlDaGVjayIsInVzZXJJZCI6IjEiLCJpYXQiOjE2MDU2MjYxNzAsImV4cCI6MTYwNTYyNjIzMH0.8m-rEAZkuqb4upAPKY7j8DhvFi8mVbmiCFDitgNYt6Y"
      }
    )
  }

  console.log('call remote ==> ', await client.getStackClient().fetchJSON('POST','/remote/org.mps.share', parameters ))
